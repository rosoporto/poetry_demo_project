from colorama import Fore

def main():
    print(Fore.YELLOW + 'I\'am main')


if __name__ == '__main__':
    main()
