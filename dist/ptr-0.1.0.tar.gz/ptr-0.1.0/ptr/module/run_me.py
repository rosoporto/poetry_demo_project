from colorama import Fore


def main():
    print(Fore.YELLOW + 'You started me')


if __name__ == '__main__':
    main()
